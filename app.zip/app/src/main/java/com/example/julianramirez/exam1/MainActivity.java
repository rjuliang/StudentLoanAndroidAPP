package com.example.julianramirez.exam1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    private static final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();

    private double loanAmount = 0.0;
    private double interestRate = 0.0;
    private double years = 5;

    private TextView yearstextView;
    private TextView monthlytextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        yearstextView = (TextView) findViewById(R.id.yearstextView);
        monthlytextView = (TextView) findViewById(R.id.monthlytextView);


        monthlytextView.setText(currencyFormat.format(0));

        EditText loanEditText = (EditText) findViewById(R.id.loanEditText);
        loanEditText.addTextChangedListener(loanEditTextWatcher);

        EditText interestRateEditText = (EditText) findViewById(R.id.interestRateEditText);
        interestRateEditText.addTextChangedListener(interestRateEditTextWatcher);

        SeekBar yearsSeekBar = (SeekBar) findViewById(R.id.SeekBar);
        yearsSeekBar.setOnSeekBarChangeListener(seekBarListener);
    }

    private void calculate() {
        yearstextView.setText(years + " yrs");

        double interest = loanAmount * (interestRate/100.0);
        double total = loanAmount + interest;
        double monthlyPayment = (total/years)/12;


        monthlytextView.setText(currencyFormat.format(monthlyPayment));
    }

    private final OnSeekBarChangeListener seekBarListener =
            new OnSeekBarChangeListener() {
                // update percent, then call calculate
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress,
                                              boolean fromUser) {

                    years = (Math.rint((double) progress / 5)*5);

                    calculate();
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) { }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) { }
            };
    private final TextWatcher loanEditTextWatcher = new TextWatcher() {
        // called when the user modifies the bill amount
        @Override
        public void onTextChanged(CharSequence s, int start,
                                  int before, int count) {

            try { // get bill amount and display currency formatted value
                loanAmount = Double.parseDouble(s.toString());
                //loan.setText(currencyFormat.format(loanAmount));
            }
            catch (NumberFormatException e) { // if s is empty or non-numeric
                //loan.setText("");
                loanAmount = 0.0;
            }

            calculate(); // update the tip and total TextViews
        }

        @Override
        public void afterTextChanged(Editable s) { }

        @Override
        public void beforeTextChanged(
                CharSequence s, int start, int count, int after) { }
    };
    private final TextWatcher interestRateEditTextWatcher = new TextWatcher() {
        // called when the user modifies the bill amount
        @Override
        public void onTextChanged(CharSequence s, int start,
                                  int before, int count) {

            try { // get bill amount and display currency formatted value
                interestRate = Double.parseDouble(s.toString());
                //interest.setText(currencyFormat.format(loanAmount));
            }
            catch (NumberFormatException e) { // if s is empty or non-numeric
                //interest.setText("");
                interestRate = 0.0;
            }

            calculate(); // update the tip and total TextViews
        }

        @Override
        public void afterTextChanged(Editable s) { }

        @Override
        public void beforeTextChanged(
                CharSequence s, int start, int count, int after) { }
    };

}
